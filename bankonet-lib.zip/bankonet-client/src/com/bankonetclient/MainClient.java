package com.bankonetclient;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.bankonet.lib.*;

import dao.DAOFactory;
import dao.DAOFactoryFile;
import metier.ClientService;
import metier.ClientServiceImpl;
import metier.CompteService;
import metier.CompteServiceImpl;

public class MainClient {
	
	private Map<String, Client> clientsList = new HashMap<String, Client>();
	private Map<Integer, String> stepsLogin = new HashMap();
	private Map<Integer, String> stepsDepot = new HashMap();
	private Map<Integer, String> stepsRetrait = new HashMap();
	private FileManager fm = new FileManager();
	private Client currentClient;
	private DAOFactory factory = new DAOFactoryFile();
	private CompteService compteService = new CompteServiceImpl(factory.getCompteDAO());
	private ClientService cs = new ClientServiceImpl(factory.getCompteDAO(), factory.getClientDAO(), compteService);
	
	private String intro;
	
	
	MainClient() {
		this.stepsLogin.put(1, "Veuillez entrer votre login:");
		this.stepsLogin.put(2, "Password:");
		this.stepsLogin.put(3, "Connexion impossible.");
		this.stepsLogin.put(4, "pwd");
		this.stepsDepot.put(0, "Choisir le compte � cr�diter:");
		this.stepsDepot.put(1, "Saisir un montant:");
		this.stepsRetrait.put(0, "Choisir le compte � d�biter:");
		this.stepsRetrait.put(1, "Saisir un montant:");
		intro = "*** Application Client ***\n"
				+ "0. Arr�ter le programme\n"
				+ "1. Consulter les soldes des comptes\n"
				+ "2. Faire un d�p�t.\n"
				+ "3. Faire un retrait.\n"
				+ "4. Faire un virement.\n"
				+ "5. Faire un virement externe.\n";
		currentClient = null;
	}
	
//	public void displayComptes(String msg) {
//		StringBuilder builder = new StringBuilder();
//		Iterator<Compte> it = this.currentClient.getComptesList().values().iterator();
//		Compte compte = null;
//		
//		while (it.hasNext()) {
//			compte = it.next();
//			builder.append(compte.toString() + "\n");
//			
//		}
//		System.out.println(builder.toString());
//		if (!msg.equals(""))
//			this.handleOption(this.getOption(msg));
//	}
	
	public String Scandat(int flag) {
		String str = "";
		Scanner scanIn = new Scanner(System.in);
		
		 if (flag == 1)
	    	 scanIn.close();
		 
		 
	     str = scanIn.nextLine();
	     	
	    
	     return str;
	}
	
	public String getOption(String msg) {
		String cOption;
	     
		System.out.println(msg);
		cOption = this.Scandat(0);
	    return cOption;
	}
	
	public boolean login() {
		int step = 0;
		boolean ok = false;
		String[] tab = new String[2];
		
		for (step =0;!ok;) {
			step = 0;
			System.out.println(this.stepsLogin.get(step+1));
			tab[step] = this.Scandat(0);
			if ((currentClient = this.clientsList.get(tab[step])) != null) {
				System.out.println(this.stepsLogin.get(++step+1));
				System.out.println(currentClient.getPwd());
				tab[step] = this.Scandat(0);
				if (currentClient.getPwd().equals(tab[step])) {
					ok = true;
				}
			}
		}
		return ok;
	}
	
//	public Compte choixCompte(String type) {
//		boolean ok = false;
//		Compte compte = null;
//		
//		this.displayComptes("");
//		while(!ok) {
//			System.out.println("Choisir un compte � " + type);
//			if ((compte = this.currentClient.getComptesList().get(this.Scandat(0))) != null) {
//				ok = true;
//			}
//		}
//		return compte;
//	}
	
//	public void faireDepot() {
//		int step = 1;
//		boolean ok = false;
//		Compte compte = null;
//		
//		compte = this.choixCompte("cr�diter");
//		while(!ok) {
//			System.out.println(this.stepsDepot.get(step));
//				try {
//					compte.crediter(Double.valueOf(Scandat(0)));
//					fm.writeData(clientsList);
//					ok = true;
//				} catch (NumberFormatException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (CompteException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		
//		this.handleOption(this.getOption(intro));
//	}
	
	
	
	public void faireRetrait() {
		int step = 1;
		boolean ok = false;
		Compte compte = null;
		double value;
		
		compte = this.choixCompte("d�biter");
		while(!ok) {
			System.out.println(this.stepsRetrait.get(step));
				try {
					if ((value = Double.valueOf(Scandat(0))) == 0) {
						ok = true;
					}
					else if (value <= compte.getSolde()) {
						compte.debiter(value);
						fm.writeData(clientsList);
						ok = true;
					}
					else
						System.out.println("Retrait Impossible: Decouvert autoris� d�pass�");
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (CompteException e) {
					e.printStackTrace();
				}
			}
		this.handleOption(this.getOption(intro));
	}
	
	public void faireVirement() {
		int step = 1;
		boolean ok = false;
		Compte compteDebit = null;
		Compte compteCredit = null;
		double value;
		
		compteDebit = this.choixCompte("d�biter");
		compteCredit = this.choixCompte("cr�diter");
		
		while(!ok) {
			System.out.println(this.stepsRetrait.get(step));
			
				if ((value = Double.valueOf(Scandat(0))) == 0) {
						ok = true;
				}
				else if (value <= compteDebit.getSolde()) {
					try {
						compteCredit.crediter(value);
						compteDebit.debiter(value);
						fm.writeData(clientsList);
						ok = true;
						} catch (CompteException e) {
							System.out.println(e.getMessage() + ": Retrait impossible.");
							ok = true;
						}
					}
				else {
						System.out.println("Solde insuffisante: Retrait Impossible.");
						this.handleOption(this.getOption(intro));
					}
		}
		this.displayComptes("");
		this.handleOption(this.getOption(intro));
	}
	
	public Compte findCompte() {
		boolean ok = false;
		String nom, prenom, lib = "";
		Iterator<Client> it = this.clientsList.values().iterator();
		Iterator<Compte> it2;
		Client client;
		Compte compte = null;
		
		while (!ok) {
			System.out.println("Choisir un nom:");
			nom = Scandat(0);
			System.out.println("Choisir un prenom:");
			prenom = Scandat(0);
			System.out.println("Choisir le libell�:");
			lib = Scandat(0);
			while (it.hasNext()) {
				client = it.next();
				if (client.getNom().equals(nom) && client.getPrenom().equals(prenom)) {
					 it2 = client.getComptesList().values().iterator();
					while(it2.hasNext()) {
						compte = it2.next();
						if (compte.getIntitule().equals(lib)) {
							return compte;
						}
					}
				}
			}
		}
		return compte;
	}
	
	public void faireVirementExt() {
		int step = 1;
		boolean ok = false;
		Compte compteDebit = null;
		Compte compteCredit = null;
		double value;
		
		compteDebit = this.choixCompte("d�biter");
		compteCredit = this.findCompte();
		
		while(!ok) {
			System.out.println(this.stepsRetrait.get(step));
			
				if ((value = Double.valueOf(Scandat(0))) == 0) {
						ok = true;
				}
				else if (value <= compteDebit.getSolde()) {
					try {
						compteCredit.crediter(value);
						compteDebit.debiter(value);
						fm.writeData(clientsList);
						ok = true;
						} catch (CompteException e) {
							System.out.println(e.getMessage() + ": Retrait impossible.");
							ok = true;
						}
					}
				else {
						System.out.println("Solde insuffisante: Retrait Impossible.");
						this.handleOption(this.getOption(intro));
					}
		}
		this.displayComptes("");
		this.handleOption(this.getOption(intro));
	}
	
	public void handleOption(String option) {
		
		if (option.equals("1")) {
			cs.displayAll(this.currentClient);
		}
		else if (option.equals("2")) {
			compteService.faireDepot(this.currentClient);
		}
		else if (option.equals("3")) {
			this.faireRetrait();
		}
		else if (option.equals("4")) {
			this.faireVirement();
		}
		else if (option.equals("5")) {
			this.faireVirementExt();
		}
		else if (option.equals("0")) {
			System.out.println("Closing App...");
			System.exit(0);
		}
	}
	
	public static void main(String[] args) {
		MainClient mainClient = new MainClient();
		mainClient.fm.getData(mainClient.clientsList);
		
		System.out.println(mainClient.clientsList.size());
		
		if (mainClient.login()) {
			mainClient.handleOption(mainClient.getOption(mainClient.intro));
		}
	}

}
