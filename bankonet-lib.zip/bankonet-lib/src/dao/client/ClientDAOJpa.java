package dao.client;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.bankonet.lib.Client;
import com.bankonet.lib.CompteException;

public class ClientDAOJpa implements ClientDAO {

	EntityManagerFactory factory = null;
	EntityManager em;
	
	public ClientDAOJpa(EntityManagerFactory fac) {
		this.factory = fac;
		 this.em = factory.createEntityManager();
	}
	
	@Override
	public Map<String, Client> findAll() {
		
		return null;
	}

	@Override
	public Client create(String nom, String prenom, String identifiant, String pwd) throws CompteException {
		return new Client(nom, prenom, identifiant, pwd);
	}

	@Override
	public Client findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Client client) {
		System.out.println("persistation");
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(client);
		et.commit();
		em.close();
	}

}
