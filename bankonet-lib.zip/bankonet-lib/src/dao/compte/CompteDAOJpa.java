package dao.compte;

import com.bankonet.lib.Client;
import com.bankonet.lib.Compte;
import com.bankonet.lib.CompteException;
import com.bankonet.lib.DBManager;
import com.mysql.jdbc.Statement;

public class CompteDAOJpa implements CompteDAO {

	@Override
	public Compte[] findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Compte create(Client client, String lib, Class<? extends Compte> type) throws CompteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Compte findById(String id, Client client) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Compte findByType(Class<? extends Compte> type, Client client) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Compte Compte, Client client) {

	}

}
