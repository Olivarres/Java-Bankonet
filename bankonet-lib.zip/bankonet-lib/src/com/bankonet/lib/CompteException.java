package com.bankonet.lib;

public class CompteException extends Exception {
	CompteException() {
		
	}
	
	public CompteException(String msg) {
		super(msg);
	}
}
