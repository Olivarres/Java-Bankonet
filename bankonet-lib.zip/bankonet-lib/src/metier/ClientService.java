package metier;

import com.bankonet.lib.Client;
import com.bankonet.lib.Compte;

public interface ClientService {
	public void createClient(String nom, String prenom, String login, String pwd);
	public void displayClients();
	public Client getClient(String id);
	public void choixClient();
	public void ajoutCompte(Class<? extends Compte> type);
	public void modifDecouvert();
}
